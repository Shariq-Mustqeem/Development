"use client";

import webPic from "assets/webPic.jpg";

export const imageUrl = {
  webPic,
};
