"use Client";
export default function Home() {
  return (
    <>
      <h1> hi my name is shariq</h1>
    </>
  );
}
