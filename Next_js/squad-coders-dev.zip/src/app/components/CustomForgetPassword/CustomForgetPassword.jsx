"use client";
w;
import React from "react";

function CustomForgetPassword({ children }) {
  return (
    <a
      href="/"
      className="font-inter text-base font-normal leading-20 text-left text-paragraphColor2 underline"
    >
      {children}
    </a>
  );
}

export default CustomForgetPassword;
