"use client";

import React from "react";

function CustomHeading({ children, className = "", ...restProps }) {
  return (
    <div
      className={`text-3xl font-inter text-paragraphColor3 ${className}`}
      {...restProps}
    >
      <h1>{children}</h1>
    </div>
  );
}

export default CustomHeading;
