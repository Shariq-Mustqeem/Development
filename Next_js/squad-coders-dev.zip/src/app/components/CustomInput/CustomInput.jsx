"use client";

import { Input } from "antd";
import { memo } from "react";
import { SVG_ICONS } from "src/svgicons/SvgIcons";

function CustomInput({
  children,
  className = " ",
  showDeleteIcon,
  handleInputDelete,
  ...restProps
}) {
  return (
    <Input
      className={`w-full h-[45px] custom-input-field ${className}`}
      placeholder={children}
      suffix={
        showDeleteIcon && (
          <div onClick={handleInputDelete} className="cursor-pointer">
            {SVG_ICONS.DeleteIcon}
          </div>
        )
      }
      {...restProps}
    />
  );
}
export default memo(CustomInput);
