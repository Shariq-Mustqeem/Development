"use client";

import React from "react";

function CustomParagraph({ children, className = "", ...restProps }) {
  return (
    <p
      className={`text-base font-inter text-paragraphColor ${className}`}
      {...restProps}
    >
      {children}
    </p>
  );
}

export default CustomParagraph;
