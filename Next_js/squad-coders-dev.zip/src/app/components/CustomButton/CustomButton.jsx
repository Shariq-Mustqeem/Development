"use client";

import React, { memo } from "react";
import { Button } from "antd";

function CustomButton({
  CustomButtonClass,
  style,
  children,
  className = "",
  ...restProps
}) {
  return (
    <Button
      style={style}
      className={`${
        CustomButtonClass === false ? "" : "custom-button"
      } ${className}`}
      {...restProps}
    >
      {children}
    </Button>
  );
}

export default memo(CustomButton);
