"use client";

export const API_URL = {
  USER: "/user",
};
